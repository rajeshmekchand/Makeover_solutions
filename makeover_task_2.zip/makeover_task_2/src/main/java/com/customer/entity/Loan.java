package com.customer.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Loan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private double loanAmount;
	private double interestRate; // Annual interest rate
	private int durationInMonths;
	private String purpose;
	private String status; // APPROVED or REJECTED
	private double interestAmount;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public int getDurationInMonths() {
		return durationInMonths;
	}
	public void setDurationInMonths(int durationInMonths) {
		this.durationInMonths = durationInMonths;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getInterestAmount() {
		return interestAmount;
	}
	public void setInterestAmount(double interestAmount) {
		this.interestAmount = interestAmount;
	}
	@Override
	public String toString() {
		return "Loan_Entity [id=" + id + ", loanAmount=" + loanAmount + ", interestRate=" + interestRate
				+ ", durationInMonths=" + durationInMonths + ", purpose=" + purpose + ", status=" + status
				+ ", interestAmount=" + interestAmount + "]";
	}
	public void setCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}
	public void setRemainingBalance(double d) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
