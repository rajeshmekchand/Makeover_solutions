package com.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.entity.Customer;
import com.lms.repository.CustomerRepository;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepo;

	@PostMapping
	public Customer addCustomer(@RequestBody Customer customer) {
		return customerRepo.save(customer);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer updated) {
		return customerRepo.findById(id).map(c -> {
			c.setName(updated.getName());
			c.setEmail(updated.getEmail());
			c.setAddress(updated.getAddress());
			c.setContactNumber(updated.getContactNumber());
			return ResponseEntity.ok(customerRepo.save(c));
		}).orElse(ResponseEntity.notFound().build());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Customer> getCustomer(@PathVariable Long id) {
		return customerRepo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}
}
