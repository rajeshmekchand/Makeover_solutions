package com.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.entity.Loan;
import com.lms.repository.CustomerRepository;
import com.lms.repository.LoanRepository;

@RestController
@RequestMapping("/api/loans")
public class LoanController {

    @Autowired
    private LoanRepository loanRepo;

    @Autowired
    private CustomerRepository customerRepo;

    @PostMapping("/apply/{customerId}")
    public ResponseEntity<Loan> applyLoan(@PathVariable Long customerId, @RequestBody Loan loan) {
        return customerRepo.findById(customerId).map(c -> {
            loan.setCustomer(c);

            // Approval Logic
            if (loan.getLoanAmount() <= 50000) {
                loan.setStatus("APPROVED");
            } else {
                loan.setStatus("PENDING");
            }

            // Interest Calculation: Simple Interest = (P×R×T)/100
            double interest = (loan.getLoanAmount() * loan.getInterestRate() * (loan.getDurationInMonths() / 12.0)) / 100;
            loan.setInterestAmount(interest);
            loan.setRemainingBalance(loan.getLoanAmount() + interest);

            return ResponseEntity.ok(loanRepo.save(loan));
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{loanId}")
    public ResponseEntity<Object> getStatus(@PathVariable Long loanId) {
        return loanRepo.findById(loanId).map(loan -> ResponseEntity.ok(loan.getStatus()))
                      .orElse(ResponseEntity.notFound().build());
    }
}

