package com.lms.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.entity.Repayment;
import com.lms.repository.LoanRepository;
import com.lms.repository.RepaymentRepository;

@RestController
@RequestMapping("/api/repayments")
public class RepaymentController {

	@Autowired
	private RepaymentRepository repaymentRepo;

	@Autowired
	private LoanRepository loanRepo;

	@PostMapping("/{loanId}")
	public ResponseEntity<Repayment> makeRepayment(@PathVariable Long loanId, @RequestBody Repayment repayment) {
		return loanRepo.findById(loanId).map(loan -> {
			repayment.setLoan(loan);
			repayment.setPaymentDate(LocalDate.now());

			loan.setRemainingBalance(loan.getRemainingBalance() - repayment.getAmountPaid());

			if (loan.getRemainingBalance() <= 0) {
				loan.setStatus("REPAID");
				loan.setRemainingBalance(0);
			}

			loanRepo.save(loan);
			return ResponseEntity.ok(repaymentRepo.save(repayment));
		}).orElse(ResponseEntity.notFound().build());
	}
}
