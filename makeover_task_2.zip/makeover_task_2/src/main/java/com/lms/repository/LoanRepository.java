package com.lms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.entity.Customer;
import com.customer.entity.Loan;

public interface LoanRepository extends JpaRepository<Loan, Integer> {

	Optional<Customer> findById(Long loanId);

	void save(Customer loan);

}
