package com.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.entity.Repayment;

public interface RepaymentRepository  extends JpaRepository<Repayment, Integer>{

}
